# Allo — PWA prête à déployer

Cette version conserve le fonctionnement existant d'Allo et ajoute l'installation comme application (PWA).

## Déploiement

Déployer le contenu de ce dossier sur un hébergement HTTPS, par exemple Vercel. Le fichier `vercel.json` configure les en-têtes nécessaires au service worker et au manifeste.

## Installation

- Android / Chrome ou Edge : le bouton **Installer Allo** peut apparaître automatiquement. Sinon : menu du navigateur → **Installer l'application** / **Ajouter à l'écran d'accueil**.
- iPhone / iPad : ouvrir le site dans Safari → **Partager** → **Sur l'écran d'accueil**.
- Une fois installée, Allo s'ouvre en mode application (`standalone`).

## Authentification

Le service worker ne met volontairement pas en cache les requêtes cross-origin, notamment Supabase. La session Supabase existante reste donc gérée par l'application sans être figée par le cache PWA.
